package VehiclesExtension;

public interface Vehicle {

    String drive(Double distance);
    void refuel(Double litters);
    String driveAC(Double distance);
}
