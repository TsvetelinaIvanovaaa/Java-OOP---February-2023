package WorkingWithAbstractionExercise.TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW;

}
