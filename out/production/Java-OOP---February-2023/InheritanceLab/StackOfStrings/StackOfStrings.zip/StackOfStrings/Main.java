package StackOfStrings;

public class Main {
    public static void main(String[] args) {
        StackOfStrings sos=new StackOfStrings();
        sos.push("1dssdf");
        sos.push("2dssdf");
        sos.push("3dssdf");
        System.out.println(sos.peek());
    }


}
