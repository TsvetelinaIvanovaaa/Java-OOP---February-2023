package FoodShortage;

public interface Buyer {
    void buyFood();
    int getFood();
}

